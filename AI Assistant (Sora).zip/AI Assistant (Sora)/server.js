const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json()); // Middleware to parse JSON bodies

// Endpoint to handle user messages
app.post('/chat', async (req, res) => {
  const userMessage = req.body.message;
  const userProfile = req.body.profile; // ASD, ADHD, Social Anxiety, etc.
  const apiKey = "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"; // Replace with your actual API key

  // Customize the prompt based on the user's profile (e.g., ASD, ADHD, Social Anxiety)
  let systemPrompt = "";
  if (userProfile === "ASD") {
    systemPrompt = "You are talking to a person with Autism Spectrum Disorder (ASD). Respond literally and avoid sarcasm or figurative language.";
  } else if (userProfile === "ADHD") {
    systemPrompt = "You are talking to a person with ADHD. Provide clear and structured responses.";
  } else if (userProfile === "Social Anxiety") {
    systemPrompt = "You are talking to someone with Social Anxiety. Be gentle, avoid being too intrusive, and respect pauses.";
  } else {
    systemPrompt = "Respond normally.";
  }

  // Sending request to OpenAI API (or your chosen AI API)
  try {
    const response = await axios.post('https://api.openai.com/v1/completions', {
      model: 'text-davinci-003', // Use GPT-3 or GPT-4 depending on your API subscription
      prompt: `${systemPrompt}\nUser: ${userMessage}\nAssistant:`,
      max_tokens: 150,
      temperature: 0.7,
    }, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
      }
    });

    // Send the AI response back to the frontend
    res.json({ reply: response.data.choices[0].text.trim() });
  } catch (error) {
    console.error("Error communicating with AI:", error);
    res.status(500).send('Error communicating with AI');
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
