// Select DOM elements
const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');
const voiceButton = document.getElementById('voice-button');
const typingIndicator = document.getElementById('typing-indicator');
const robotFace = document.getElementById('robot-face');

// Add event listener to the "Send" button
sendButton.addEventListener('click', sendMessage);

// Add event listener for pressing Enter in the textarea
userInput.addEventListener('keydown', function (e) {
  if (e.key === 'Enter') {
    sendMessage();
  }
});

// Function to change Sora's expression
function changeExpression(expression) {
  switch(expression) {
    case 'happy':
      robotFace.src = 'Sora-Happy.png'; // Replace with actual image
      break;
    case 'thinking':
      robotFace.src = 'Sora-Thinking.png'; // Replace with actual image
      break;
    case 'surprised':
      robotFace.src = 'Sora-Suprised.png'; // Replace with actual image
      break;
    case 'neutral':
    default:
      robotFace.src = 'Sora-Neutral.png'; // Default neutral expression
      break;
  }
}
// Function to speak the AI response out loud (Text-to-Speech)
function speakResponse(text) {
    const speech = new SpeechSynthesisUtterance();
    speech.text = text;
    speech.lang = 'en-US';  // You can change the language to fit your needs
    speech.volume = 1;      // Volume (0 to 1)
    speech.rate = 1;        // Speed of the speech
    speech.pitch = 1;       // Pitch of the voice
    
    window.speechSynthesis.speak(speech);
  }
  
  // Update your sendMessage function to speak out the response
  async function sendMessage() {
    const message = userInput.value.trim();
    if (message) {
      // Display user message in the chatbox
      displayMessage(message, 'user');
      
      // Change expression to thinking while processing
      changeExpression('thinking');
  
      // Clear the input field
      userInput.value = '';
  
      // Show typing indicator
      typingIndicator.style.display = 'block';
  
      try {
        // Get AI response from the API
        const aiResponse = await getAIResponse(message);
  
        // Hide typing indicator
        typingIndicator.style.display = 'none';
  
        // Display Sora's response
        displayMessage(aiResponse, 'sora');
  
        // Speak out the AI response (Text-to-Speech)
        speakResponse(aiResponse);
  
        // Change expression to happy after responding
        changeExpression('happy');
      } catch (error) {
        console.error('Error:', error);
        typingIndicator.style.display = 'none';
        displayMessage('Sorry, there was an error processing your request. Please try again.', 'sora');
        changeExpression('neutral');
      }
    }
  }
  

// Function to send user message
async function sendMessage() {
  const message = userInput.value.trim();
  if (message) {
    // Display user message in the chatbox
    displayMessage(message, 'user');
    
    // Change expression to thinking while processing
    changeExpression('thinking');

    // Clear the input field
    userInput.value = '';

    // Show typing indicator
    typingIndicator.style.display = 'block';

    try {
      // Get AI response from the API
      const aiResponse = await getAIResponse(message);

      // Hide typing indicator
      typingIndicator.style.display = 'none';

      // Display Sora's response
      displayMessage(aiResponse, 'sora');

      // Change expression to happy after responding
      changeExpression('happy');
    } catch (error) {
      console.error('Error:', error);
      typingIndicator.style.display = 'none';
      displayMessage('Sorry, there was an error processing your request. Please try again.', 'sora');
      changeExpression('neutral');
    }
  }
}

// Function to display messages in the chatbox
function displayMessage(message, sender) {
  const messageDiv = document.createElement('div');
  messageDiv.classList.add(sender);
  messageDiv.textContent = message;
  chatBox.appendChild(messageDiv);
  chatBox.scrollTop = chatBox.scrollHeight; // Auto scroll to the bottom
}

// Function to get AI response (using OpenAI API)
async function getAIResponse(userMessage) {
  const apiKey = "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"; // Replace with your actual API key
  const endpoint = "https://api.openai.com/v1/completions"; // OpenAI API endpoint

  // Request body
  const requestBody = {
    model: "gpt-4", // You can change this to gpt-3.5-turbo or other models if needed
    messages: [
      { role: "system", content: "You are an AI assistant for a neurodivergent-friendly service." },
      { role: "user", content: userMessage }
    ],
    max_tokens: 150,
  };

  // Fetch API request to OpenAI
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify(requestBody),
  });

  // Parse the response and return the AI's reply
  const data = await response.json();
  return data.choices[0].message.content.trim(); // The response from the AI
}

// Voice Input: Initialize speech recognition
const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
recognition.lang = 'en-US';

// Add event listener for voice button
voiceButton.addEventListener('click', () => {
  recognition.start(); // Start listening for speech input
});

// Handle speech input (transcription)
recognition.onresult = function (event) {
  const speechToText = event.results[0][0].transcript;
  userInput.value = speechToText;
  sendMessage();
};

// Error handling for speech recognition
recognition.onerror = function (event) {
  alert('Voice recognition error: ' + event.error);
};
// Font size adjustment
const fontSizeInput = document.getElementById('font-size');
const fontSizeValue = document.getElementById('font-size-value');

fontSizeInput.addEventListener('input', function() {
  const newSize = fontSizeInput.value + 'px';
  document.body.style.fontSize = newSize;
  fontSizeValue.textContent = newSize;
});

