require('dotenv').config();
const express = require("express");
const cors = require("cors");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(cors());

app.post("/chat", (req, res) => {
    const userMessage = req.body.message;
    
    // Prevent malicious input
    if (!userMessage || userMessage.includes("<script>")) {
        return res.status(400).json({ reply: "Invalid input detected." });
    }

    // Process the request (Replace with AI API calls)
    const botReply = `You said: ${userMessage}`;
    res.json({ reply: botReply });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
const rateLimit = require("express-rate-limit");

const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 50, // Limit each IP to 50 requests per window
    message: "Too many reqyests, Please try again later0."
});

app.use(limiter);
function sanitizeInput(text) {
    return text.replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
const sanitizedMessage = sanitizeInput(req.body.message);
