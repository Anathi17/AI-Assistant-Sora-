const API_KEY = 'your-api-key-here'; // Replace with your actual API key
const API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent';

const chatMessages = document.getElementById('chat-messages');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');

// Predefined Responses for Basic Questions (Fallback if API Fails)
const predefinedResponses = {
    "hello": "Hi there! How can I assist you?",
    "how are you": "I'm just an AI, but I'm always ready to help!",
    "what is autism": "Autism Spectrum Disorder (ASD) affects communication, behavior, and social interaction.",
    "symptoms of autism": "Early signs include delayed speech, difficulty with social interactions, repetitive behaviors, and sensory sensitivities.",
    "how to support autistic children": "Create structured routines, use clear communication, and provide sensory-friendly environments.",
    "bye": "Goodbye! Have a great day!"
};

// Function to fetch AI-generated response from the API
async function generateResponse(prompt) {
    try {
        const response = await fetch(`${API_URL}?key=${API_KEY}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                contents: [{ parts: [{ text: prompt }] }]
            })
        });

        if (!response.ok) throw new Error('Failed to generate response');

        const data = await response.json();
        return data.candidates[0].content.parts[0].text;
    } catch (error) {
        console.error('Error:', error);
        return predefinedResponses[prompt.toLowerCase()] || "I'm sorry, I don't understand that.";
    }
}

// Function to clean Markdown formatting from AI responses
function cleanMarkdown(text) {
    return text.replace(/#{1,6}\s?/g, '')
               .replace(/\*\*/g, '')
               .replace(/\n{3,}/g, '\n\n')
               .trim();
}

// Function to add messages to the chat UI
function addMessage(message, isUser) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', isUser ? 'user-message' : 'bot-message');

    const profileImage = document.createElement('img');
    profileImage.classList.add('profile-image');
    profileImage.src = isUser ? 'user.jpg' : 'bot.jpg';
    profileImage.alt = isUser ? 'User' : 'Bot';

    const messageContent = document.createElement('div');
    messageContent.classList.add('message-content');
    messageContent.textContent = message;

    messageElement.appendChild(profileImage);
    messageElement.appendChild(messageContent);
    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Function to process user input and generate a response
async function handleUserInput() {
    const userMessage = userInput.value.trim();
    if (!userMessage) return;

    addMessage(userMessage, true);
    userInput.value = '';
    sendButton.disabled = true;
    userInput.disabled = true;

    try {
        const botMessage = await generateResponse(userMessage);
        addMessage(cleanMarkdown(botMessage), false);
    } catch (error) {
        addMessage("Sorry, I'm having trouble responding right now. Please try again.", false);
    } finally {
        sendButton.disabled = false;
        userInput.disabled = false;
        userInput.focus();
    }
}

// Event Listeners for Chat Interaction
sendButton.addEventListener('click', handleUserInput);
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleUserInput();
    }
});

